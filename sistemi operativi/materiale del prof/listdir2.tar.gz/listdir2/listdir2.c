#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <grp.h>
#include <limits.h>
#include <pwd.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

static const char* program_name;

__attribute__((noreturn, format(printf, 1, 2)))
void fatal(const char *format, ...) {
  va_list ap;

  va_start(ap, format);
  fprintf(stderr, "%s: FATAL: ", program_name);
  vfprintf(stderr, format, ap);
  fprintf(stderr, "\n");
  va_end(ap);
  exit(1);
}

__attribute__((noreturn))
void usage(void) {
  fprintf(stderr, "usage: %s [PATH]\n", program_name);
  exit(1);
}

DIR *opendir_or_die(const char *path) {
  errno = 0;
  DIR *dir = opendir(path);
  if (dir == NULL) {
    // Some error occurred.
    switch (errno) {

    case ENOENT:
      if (strlen(path) == 0) {
        fatal("specified path is empty");
      }
      else {
        fatal("specified path `%s' does not exist", path);
      }

    case EACCES:
      fatal("insufficient permissions to access `%s'", path);

    default:
      fatal("unclassified error %d returned by opendir()", errno);
    }
  }
  return dir;
}

void closedir_or_die(DIR *dir) {
  assert(dir != NULL);
  int r = closedir(dir);
  if (r < 0) {
    fatal("closedir() called with bogus argument");
  }
}

struct dirent *readdir_or_die(DIR *dir) {
  errno = 0;
  struct dirent *e = readdir(dir);
  if (e == NULL && errno != 0) {
    //fatal("unspecified error %d returned by readdir()", errno);
    fatal("unspecified error returned by readdir()");
  }
  return e;
}

char file_type_char(unsigned char dt_num) {
  switch(dt_num) {
  case DT_BLK:
    return 'b';
  case DT_CHR:
    return 'c';
  case DT_DIR:
    return 'd';
  case DT_FIFO:
    return 'p';
  case DT_LNK:
    return 'l';
  case DT_REG:
    return '-';
  case DT_SOCK:
    return 's';
  case DT_UNKNOWN:
  default:
    return '?';
  }
}

#define TIME_BUF_SIZE 30

// buf needs to store 30 characters
void print_timespec(struct timespec *ts) {
    struct tm t;
    char buf[TIME_BUF_SIZE];

    tzset();
    if (localtime_r(&(ts->tv_sec), &t) == NULL) {
      fatal("localtime_r() failed");
    }

    int r = strftime(buf, TIME_BUF_SIZE, "%b %2d %Y %H:%M:%S", &t);
    if (r == 0) {
      fatal("strftime() failed");
    }

    printf("%s", buf);
}

void print_rwx(unsigned char bits) {
  char r = (bits & 4) ? 'r' : '-';
  char w = (bits & 2) ? 'w' : '-';
  char x = (bits & 1) ? 'x' : '-';
  printf("%c%c%c", r, w, x);
}

void print_directory_tree(const char *path) {
  DIR *dir = opendir_or_die(path);
  assert(dir != NULL);

  struct dirent *dir_entry;

  printf("%s:\n", path);
  while (true) {
    dir_entry = readdir_or_die(dir);
    if (dir_entry == NULL) {
      break;
    }

    assert(dir_entry != NULL);

    const char *child = dir_entry->d_name;

    // Buffer to construct the path to this child.
    char path_to_child[PATH_MAX];
    int r = snprintf(path_to_child, PATH_MAX, "%s/%s",
                     path,
                     child);
    if (r >= PATH_MAX) {
      fatal("maximum path length exceeded trying to recurse\
 on `%s' from `%s'",
            path, child);
    }

    struct stat statbuf;
    r = stat(path_to_child, &statbuf);
    if (r < 0) {
      fatal("stat(%s, statbuf) gave error %d (%s)",
            path_to_child, errno, strerror(errno));
    }

    unsigned mode = statbuf.st_mode & 0777;

    // Print the file type letter.
    printf("%c", file_type_char(dir_entry->d_type));

    // Print rwx for the user.
    print_rwx(mode >> 6);
    // Print rwx for the group.
    print_rwx((mode >> 3) & 7);
    // Print rwx for the others.
    print_rwx(mode & 7);

    // Print the number of hard links.
    printf(" %lu ", statbuf.st_nlink);

    // Print the user id.
    struct passwd *passwd = getpwuid(statbuf.st_uid);
    if (passwd == NULL) {
      printf("%u", statbuf.st_uid);
    }
    else {
      printf("%s", passwd->pw_name);
    }

    printf(" ");

    // Print the group id.
    struct group *group = getgrgid(statbuf.st_gid);
    if (group == NULL) {
      printf("%u", statbuf.st_gid);
    }
    else {
      printf("%s", group->gr_name);
    }

    // Print the file dimension.
    printf(" %lu ", statbuf.st_size);

    print_timespec(&statbuf.st_mtim);

    // Print the file name.
    printf(" %s", dir_entry->d_name);

    // If we have just printed a symbolic link name, print also
    // its pointee.
    if (dir_entry->d_type == DT_LNK) {
      char symbolink_link_pointee[PATH_MAX];
      ssize_t r = readlink(path_to_child, symbolink_link_pointee, PATH_MAX);
      if (r < 0) {
        fatal("readlink(%s, ...) gave error %d (%s)",
              path_to_child, errno, strerror(errno));
      }
      else if (r >= PATH_MAX) {
        symbolink_link_pointee[PATH_MAX - 1] = '\0';
        fatal("maximum path length exceeded trying to print\
 symbolink link pointee of `%s': truncated to `%s'",
            path_to_child, symbolink_link_pointee);
      }
      symbolink_link_pointee[r] = '\0';
      printf(" -> %s\n", symbolink_link_pointee);
    }
    else {
      printf("\n");
    }
  }

  rewinddir(dir);

  while (true) {
    dir_entry = readdir_or_die(dir);
    if (dir_entry == NULL) {
      break;
    }

    assert(dir_entry != NULL);

    const char *child = dir_entry->d_name;
    if (dir_entry->d_type == DT_DIR
        && strcmp(child, ".") != 0
        && strcmp(child, "..") != 0) {

      // Buffer to construct the path to this child.
      char path_to_child[PATH_MAX];
      int r = snprintf(path_to_child, PATH_MAX, "%s/%s",
                       path,
                       child);
      if (r >= PATH_MAX) {
        fatal("maximum path length exceeded trying to recurse\
 on `%s' from `%s'",
              path, child);
      }

      printf("\n");
      print_directory_tree(path_to_child);
    }
  }

  closedir_or_die(dir);
}

int main(int argc, char *argv[]) {
  program_name = argv[0];

  const char* path;

  if (argc > 2) {
    usage();
  }

  if (argc == 1) {
    path = ".";
  }
  else {
    path = argv[1];
  }

  print_directory_tree(path);

  return 0;
}
