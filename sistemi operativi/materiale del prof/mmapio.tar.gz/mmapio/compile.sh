#!/bin/bash

for f in read write
do
    gcc -g -W -Wall "${f}.c" -o "${f}mmap"
done

