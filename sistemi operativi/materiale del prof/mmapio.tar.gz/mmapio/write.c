#include <sys/mman.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

int main() {
  int fd = open("mymappedfile", O_CREAT|O_RDWR, 0664);
  if (fd == -1) {
    fprintf(stderr, "open() failed with error \"%s\"\n", strerror(errno));
    return 1;
  }

  int s = ftruncate(fd, sizeof(int)*1000000);
  if (s == -1) {
    fprintf(stderr, "ftruncate() failed with error \"%s\"\n", strerror(errno));
    return 1;
  }

  void *r = mmap(NULL, sizeof(int)*1000000, PROT_WRITE, MAP_SHARED,
                 fd, 0);
  if (r == MAP_FAILED) {
    fprintf(stderr, "mmap() failed with error \"%s\"\n", strerror(errno));
    return 1;
  }

  int *p = r;
  for (int i = 0; i < 1000000; ++i) {
    p[i] = i;
  }

  (void) munmap(p, sizeof(int)*1000000);
  close(fd);
  return 0;
}

