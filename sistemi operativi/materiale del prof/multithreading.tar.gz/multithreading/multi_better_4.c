#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#ifndef MAX
#define MAX 20000000
#endif

#define ENUM_PRIM_SIZE 25
#define PRIM_PRINT_SIZE 25

#define NUM_THREADS_PRIM 12
#define NUM_THREADS_PRINT 2

typedef uint32_t natural_t;

typedef struct {
  size_t size;
  size_t in;
  size_t out;
  pthread_mutex_t mutex;
  sem_t full;
  sem_t empty;
  natural_t buffer[];
} bounded_buffer_t;

const char *program_name = NULL;

void mutex_init_or_die(pthread_mutex_t *mutex_p) {
  int r = pthread_mutex_init(mutex_p, NULL);
  if (r != 0) {
    fprintf(stderr, "%s: pthread_mutex_init returned %d\n",
            program_name, r);
    exit(1);
  }
}

void mutex_lock_or_die(pthread_mutex_t *mutex_p) {
  int r = pthread_mutex_lock(mutex_p);
  if (r != 0) {
    fprintf(stderr, "%s: pthread_mutex_lock returned %d\n",
            program_name, r);
    exit(1);
  }
}

void mutex_unlock_or_die(pthread_mutex_t *mutex_p) {
  int r = pthread_mutex_unlock(mutex_p);
  if (r != 0) {
    fprintf(stderr, "%s: pthread_mutex_unlock returned %d\n",
            program_name, r);
    exit(1);
  }
}

void sem_init_or_die(sem_t *sem_p, unsigned value) {
  int r = sem_init(sem_p, 0, value);
  if (r != 0) {
    fprintf(stderr, "%s: sem_init returned %d\n",
            program_name, r);
    exit(1);
  }
}

void sem_wait_or_die(sem_t *sem_p) {
  int r = sem_wait(sem_p);
  if (r != 0) {
    fprintf(stderr, "%s: sem_wait returned %d\n",
            program_name, r);
    exit(1);
  }
}

void sem_post_or_die(sem_t *sem_p) {
  int r = sem_post(sem_p);
  if (r != 0) {
    fprintf(stderr, "%s: sem_post returned %d\n",
            program_name, r);
    exit(1);
  }
}

void insert_item(bounded_buffer_t *bb_p, natural_t item) {
  sem_wait_or_die(&bb_p->empty);
  mutex_lock_or_die(&bb_p->mutex);
  assert(bb_p->size != 0);
  assert(bb_p->in < bb_p->size);
  bb_p->buffer[bb_p->in] = item;
  bb_p->in = (bb_p->in + 1) % bb_p->size;
  mutex_unlock_or_die(&bb_p->mutex);
  sem_post_or_die(&bb_p->full);
}

void remove_item(bounded_buffer_t *bb_p, natural_t *item_p) {
  sem_wait_or_die(&bb_p->full);
  mutex_lock_or_die(&bb_p->mutex);
  assert(bb_p->size != 0);
  assert(bb_p->out < bb_p->size);
  *item_p = bb_p->buffer[bb_p->out];
  bb_p->out = (bb_p->out + 1) % bb_p->size;
  mutex_unlock_or_die(&bb_p->mutex);
  sem_post_or_die(&bb_p->empty);
}

bounded_buffer_t
*new_buffer_p(size_t size) {
  const size_t num_bytes
    = sizeof(bounded_buffer_t) + sizeof(natural_t) * size;
  bounded_buffer_t *p = malloc(num_bytes);
  assert(p != NULL);
  memset(p, 0, num_bytes);
  p->size = size;
  mutex_init_or_die(&p->mutex);
  sem_init_or_die(&p->empty, size);
  sem_init_or_die(&p->full, 0);
  return p;
}


void dispose_buffer_p(bounded_buffer_t *p) {
  free(p);
}

static natural_t num_printed = 0;

void print(natural_t item) {
#ifndef NOPRINT
  printf("%d\n", item);
#endif
  ++num_printed;
}

natural_t isqrt(natural_t n) {
  natural_t i, s;

  /* First find an approximation to floor(sqrt(n)) of the form 2^k. */
  i = n;
  s = 1;
  while (i >= 2) {
    i >>= 2;
    s <<= 1;
  }

  do {
    s = (s + n / s) / 2;
  }
  while (!(s*s <= n && (s*s > s*(s+2) || n <= s*(s+2))));
  /* Short explanation: As mathematically s*(s+2) < 2*ULONG_MAX,
     the condition s*s > s*(s+2) is evaluated as true when s*(s+2)
     "overflows" but not s*s. This implies that mathematically, one
     has s*s <= n <= s*(s+2). If s*s "overflows", this means that n
     is "large" and the inequality n <= s*(s+2) cannot be satisfied. */
  return s;
}

bool is_prime(natural_t n) {
  if (n <= 1) {
    return false;
  }

  const natural_t isqrt_n = isqrt(n);
  for (natural_t i = 2; i <= isqrt_n; ++i) {
    if (n % i == 0) {
      return false;
    }
  }
  return true;
}

typedef struct {
  pthread_t id;
  bounded_buffer_t *bb_in;
  bounded_buffer_t *bb_out;
} thread_data_t;

thread_data_t thread_data[1 + NUM_THREADS_PRIM + NUM_THREADS_PRINT];

void* enumerator(void *p) {
  thread_data_t *thread_data_p = (thread_data_t*) p;
  for (natural_t next_enum = 2; next_enum <= MAX; ++next_enum) {
    insert_item(thread_data_p->bb_out, next_enum);
  }
  return NULL;
}

void* tester(void *p) {
  thread_data_t *thread_data_p = (thread_data_t*) p;
  while (true) {
    natural_t item;
    remove_item(thread_data_p->bb_in, &item);
    if (is_prime(item)) {
      insert_item(thread_data_p->bb_out, item);
    }
  }
  return NULL;
}

void* printer(void *p) {
  thread_data_t *thread_data_p = (thread_data_t*) p;
  while (true) {
    natural_t item;
    remove_item(thread_data_p->bb_in, &item);
    print(item);
  }
  return NULL;
}

int
main(int argc, char* argv[]) {
  (void) argc;
  program_name = argv[0];

  bounded_buffer_t
    *bb_enum_prim_p = new_buffer_p(ENUM_PRIM_SIZE);
  bounded_buffer_t
    *bb_prim_print_p = new_buffer_p(PRIM_PRINT_SIZE);

  int status;
  uint32_t num_threads = 0;

  thread_data[num_threads].bb_in = NULL;
  thread_data[num_threads].bb_out = bb_enum_prim_p;
  status = pthread_create(&thread_data[num_threads].id,
                          NULL,
                          &enumerator,
                          &thread_data[num_threads]);
  if (status != 0) {
    fprintf(stderr, "%s: error creating thread %d\n",
            program_name, num_threads);
    return 1;
  }
  ++num_threads;

  for (unsigned n = 0; n < NUM_THREADS_PRIM; ++n) {
    thread_data[num_threads].bb_in = bb_enum_prim_p;
    thread_data[num_threads].bb_out = bb_prim_print_p;
    status = pthread_create(&thread_data[num_threads].id,
                            NULL,
                            &tester,
                            &thread_data[num_threads]);
    if (status != 0) {
      fprintf(stderr, "%s: error creating thread %d\n",
              program_name, num_threads);
      return 2;
    }
    ++num_threads;
  }

  for (unsigned n = 0; n < NUM_THREADS_PRINT; ++n) {
    thread_data[num_threads].bb_in = bb_prim_print_p;
    thread_data[num_threads].bb_out = NULL;
    status = pthread_create(&thread_data[num_threads].id,
                            NULL,
                            &printer,
                            &thread_data[num_threads]);
    if (status != 0) {
      fprintf(stderr, "%s: error creating thread %d\n",
              program_name, num_threads);
      return 3;
    }
    ++num_threads;
  }

  for (unsigned i = 0; i < num_threads; ++i) {
    int status = pthread_join(thread_data[i].id, NULL);
    if (status != 0) {
      fprintf(stderr, "%s: error joining thread %d\n",
              program_name, i);
      return 4;
    }
  }

  dispose_buffer_p(bb_prim_print_p);
  dispose_buffer_p(bb_enum_prim_p);

  printf("%d prime numbers found\n", num_printed);

  return 0;
}
