#!/bin/sh

for k in *.c
do
    gcc -g -W -Wall -o $(basename $k .c).exe $k
done
