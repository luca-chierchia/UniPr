#include <assert.h>
//#include <errno.h>
//#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
//#include <unistd.h>

#ifndef MAX
#define MAX 20000000
#endif

#define ENUM_PRIM_SIZE 25
#define PRIM_PRINT_SIZE 25

typedef uint32_t natural_t;

typedef struct {
  size_t size;
  size_t in;
  size_t out;
  size_t count;
  natural_t buffer[];
} bounded_buffer_t;

bool insert_item(bounded_buffer_t *bb_p, natural_t item) {
  assert(bb_p->size != 0);
  assert(bb_p->count <= bb_p->size);
  if (bb_p->count == bb_p->size) {
    // Buffer is full: cannot insert.
    return false;
  }
  else {
    assert(bb_p->in < bb_p->size);
    bb_p->buffer[bb_p->in] = item;
    bb_p->in = (bb_p->in + 1) % bb_p->size;
    ++(bb_p->count);
    return true;
  }
}

bool remove_item(bounded_buffer_t *bb_p, natural_t *item_p) {
  assert(bb_p->size != 0);
  assert(bb_p->count <= bb_p->size);
  if (bb_p->count == 0) {
    // Buffer is empty: cannot remove.
    return false;
  }
  else {
    assert(bb_p->out < bb_p->size);
    *item_p = bb_p->buffer[bb_p->out];
    bb_p->out = (bb_p->out + 1) % bb_p->size;
    --(bb_p->count);
    return true;
  }
}

bounded_buffer_t
*new_buffer_p(size_t size) {
  const size_t num_bytes
    = sizeof(bounded_buffer_t) + sizeof(natural_t) * size;
  bounded_buffer_t *p = malloc(num_bytes);
  assert(p != NULL);
  memset(p, 0, num_bytes);
  p->size = size;
  return p;
}


void dispose_buffer_p(bounded_buffer_t *p) {
  free(p);
}

static natural_t num_printed = 0;

void print(natural_t item) {
#ifndef NOPRINT
  printf("%d\n", item);
#else
  (void) item;
#endif
  ++num_printed;
}

natural_t isqrt(natural_t n) {
  natural_t i, s;

  /* First find an approximation to floor(sqrt(n)) of the form 2^k. */
  i = n;
  s = 1;
  while (i >= 2) {
    i >>= 2;
    s <<= 1;
  }

  do {
    s = (s + n / s) / 2;
  }
  while (!(s*s <= n && (s*s > s*(s+2) || n <= s*(s+2))));
  /* Short explanation: As mathematically s*(s+2) < 2*ULONG_MAX,
     the condition s*s > s*(s+2) is evaluated as true when s*(s+2)
     "overflows" but not s*s. This implies that mathematically, one
     has s*s <= n <= s*(s+2). If s*s "overflows", this means that n
     is "large" and the inequality n <= s*(s+2) cannot be satisfied. */
  return s;
}

bool is_prime(natural_t n) {
  if (n <= 1) {
    return false;
  }

  const natural_t isqrt_n = isqrt(n);
  for (natural_t i = 2; i <= isqrt_n; ++i) {
    if (n % i == 0) {
      return false;
    }
  }
  return true;
}

int
main() {
  bounded_buffer_t
    *bb_enum_prim_p = new_buffer_p(ENUM_PRIM_SIZE);
  bounded_buffer_t
    *bb_prim_print_p = new_buffer_p(PRIM_PRINT_SIZE);

  natural_t next_enum = 2;
  bool done_something;
  do {
    natural_t item;
    done_something = false;

    // Start from the bottom to make space: see if something is ready
    // for printing.
    if (remove_item(bb_prim_print_p, &item)) {
      print(item);
      done_something = true;
    }

    if (remove_item(bb_enum_prim_p, &item)) {
      if (is_prime(item)) {
        bool inserted = insert_item(bb_prim_print_p, item);
        assert(inserted);
      }
      done_something = true;
    }

    if (next_enum < MAX) {
      if (insert_item(bb_enum_prim_p, next_enum)) {
        ++next_enum;
        done_something = true;
      }
    }
  } while (done_something);

  dispose_buffer_p(bb_prim_print_p);
  dispose_buffer_p(bb_enum_prim_p);

  printf("%d prime numbers found\n", num_printed);

  return 0;
}

