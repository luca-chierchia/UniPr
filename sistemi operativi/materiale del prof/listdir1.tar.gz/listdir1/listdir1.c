#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdarg.h>
#include <limits.h>

static const char* program_name;

__attribute__((noreturn, format(printf, 1, 2)))
void fatal(const char *format, ...) {
  va_list ap;

  va_start(ap, format);
  fprintf(stderr, "%s: FATAL: ", program_name);
  vfprintf(stderr, format, ap);
  fprintf(stderr, "\n");
  va_end(ap);
  exit(1);
}

__attribute__((noreturn))
void usage(void) {
  fprintf(stderr, "usage: %s [PATH]\n", program_name);
  exit(1);
}

DIR *opendir_or_die(const char *path) {
  errno = 0;
  DIR *dir = opendir(path);
  if (dir == NULL) {
    // Some error occurred.
    switch (errno) {

    case ENOENT:
      if (strlen(path) == 0) {
        fatal("specified path is empty");
      }
      else {
        fatal("specified path `%s' does not exist", path);
      }

    case EACCES:
      fatal("insufficient permissions to access `%s'", path);

    default:
      fatal("unclassified error %d returned by opendir()", errno);
    }
  }
  return dir;
}

void closedir_or_die(DIR *dir) {
  assert(dir != NULL);
  int r = closedir(dir);
  if (r < 0) {
    fatal("closedir() called with bogus argument");
  }
}

struct dirent *readdir_or_die(DIR *dir) {
  errno = 0;
  struct dirent *e = readdir(dir);
  if (e == NULL && errno != 0) {
    //fatal("unspecified error %d returned by readdir()", errno);
    fatal("unspecified error returned by readdir()");
  }
  return e;
}

char file_type_char(unsigned char dt_num) {
  switch(dt_num) {
  case DT_BLK:
    return 'b';
  case DT_CHR:
    return 'c';
  case DT_DIR:
    return 'd';
  case DT_FIFO:
    return 'f';
  case DT_LNK:
    return 'l';
  case DT_REG:
    return '-';
  case DT_SOCK:
    return 's';
  case DT_UNKNOWN:
  default:
    return '?';
  }
}

void print_directory_tree(const char *path) {
  DIR *dir = opendir_or_die(path);
  assert(dir != NULL);

  struct dirent *dir_entry;

  printf("%s:\n", path);
  while (true) {
    dir_entry = readdir_or_die(dir);
    if (dir_entry == NULL) {
      break;
    }

    assert(dir_entry != NULL);
    printf("%c %s\n",
           file_type_char(dir_entry->d_type),
           dir_entry->d_name);
  }

  rewinddir(dir);

  while (true) {
    dir_entry = readdir_or_die(dir);
    if (dir_entry == NULL) {
      break;
    }

    assert(dir_entry != NULL);

    const char *child = dir_entry->d_name;
    if (dir_entry->d_type == DT_DIR
        && strcmp(child, ".") != 0
        && strcmp(child, "..") != 0) {
      // Buffer to construct the path to this child.
      char path_to_child[PATH_MAX];
      int r = snprintf(path_to_child, PATH_MAX, "%s/%s",
                       path,
                       child);
      if (r >= PATH_MAX) {
        fatal("maximum path length exceeded trying to recurse\
 on `%s' from `%s'",
              path, child);
      }


      printf("\n");
      print_directory_tree(path_to_child);
    }
  }

  closedir_or_die(dir);
}

int main(int argc, char *argv[]) {
  program_name = argv[0];

  const char* path;

  if (argc > 2) {
    usage();
  }

  if (argc == 1) {
    path = ".";
  }
  else {
    path = argv[1];
  }

  print_directory_tree(path);

  return 0;
}
